//
//  ViewController.swift
//  francesco_greetingapp
//
//  Created by Admin on 07/10/16.
//  Copyright © 2016 Admin. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var inputTxtfield: UITextField!
    
    @IBAction func submitbtn(_ sender: UIButton) {
        displayText.text = "hello " + inputTxtfield.text!
        
    }
    
    
    @IBOutlet weak var displayText: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

